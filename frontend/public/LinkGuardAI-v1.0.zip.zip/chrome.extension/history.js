const API = "http://127.0.0.1:8000/scan/history";

const historyContainer = document.getElementById("history");
const statsContainer = document.getElementById("stats");
const clearBtn = document.getElementById("clear");

function renderStats(scans) {

  const total = scans.length;
  const safeCount = scans.filter(s => s.prediction === "Safe").length;
  const phishingCount = total - safeCount;

  statsContainer.innerHTML = `
    <div class="stat">
      <div class="num">${total}</div>
      <div class="lbl">Total Scans</div>
    </div>
    <div class="stat safe">
      <div class="num">${safeCount}</div>
      <div class="lbl">Safe</div>
    </div>
    <div class="stat danger">
      <div class="num">${phishingCount}</div>
      <div class="lbl">Phishing</div>
    </div>
  `;

}

async function loadHistory() {

  historyContainer.innerHTML =
    '<div class="loading">Loading...</div>';

  try {

    const response = await fetch(API);

    const scans = await response.json();

    if (scans.length === 0) {

      statsContainer.innerHTML = "";

      historyContainer.innerHTML = `
        <div class="loading">
          No scan history found.
        </div>
      `;

      return;

    }

    renderStats(scans);

    historyContainer.innerHTML = "";

    scans.slice(0, 20).forEach(scan => {

      const isSafe = scan.prediction === "Safe";

      const item = document.createElement("div");

      item.className = "item";

      item.innerHTML = `

        <div class="badge ${isSafe ? "safe" : "phishing"}">
          ${isSafe
            ? '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 6L9 17l-5-5"/></svg>'
            : '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 9v4"/><path d="M12 17h.01"/><path d="M10.3 3.9L2.5 17a2 2 0 0 0 1.7 3h15.6a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/></svg>'
          }
        </div>

        <div class="item-body">
          <div class="url">${scan.url}</div>
          <div class="meta">
            <span class="tag ${isSafe ? "safe" : "phishing"}">${scan.prediction}</span>
            <span class="time">${new Date(scan.created_at).toLocaleString()}</span>
          </div>
        </div>

      `;

      historyContainer.appendChild(item);

    });

  }

  catch {

    statsContainer.innerHTML = "";

    historyContainer.innerHTML = `
      <div class="loading">
        Unable to load history.
      </div>
    `;

  }

}
clearBtn.onclick = async () => {

    const confirmClear = confirm(
        "Clear all scan history?"
    );

    if (!confirmClear)
        return;

    try {

        const response = await fetch(
            "http://127.0.0.1:8000/scan/history",
            {
                method: "DELETE"
            }
        );

        const result = await response.json();

        alert(result.message);

        loadHistory();

    }

    catch {

        alert("Unable to clear history.");

    }

};