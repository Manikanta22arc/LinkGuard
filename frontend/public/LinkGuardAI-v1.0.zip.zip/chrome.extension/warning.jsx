import {
  FaShieldAlt,
  FaArrowLeft,
  FaChevronDown,
  FaLockOpen,
  FaCalendarAlt,
  FaClone,
} from "react-icons/fa";
import { motion, MotionConfig } from "framer-motion";
import { useEffect, useRef, useState } from "react";
import "./Warning.css";

const DEFAULT_REASONS = [
  {
    icon: <FaCalendarAlt />,
    title: "Recently registered domain",
    desc: "This domain was registered only a few days ago — a pattern common in phishing campaigns.",
  },
  {
    icon: <FaLockOpen />,
    title: "No valid security certificate",
    desc: "The connection to this site isn't secured with a trusted certificate.",
  },
  {
    icon: <FaClone />,
    title: "Resembles a known login page",
    desc: "The page layout closely matches a site reported for impersonating another brand.",
  },
];

function Warning({
  url = "http://secure-login-alert.example.com/verify",
  reasons = DEFAULT_REASONS,
  onGoBack,
  onProceed,
}) {
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const panelRef = useRef(null);

  let domain = url;
  try {
    domain = new URL(url).hostname;
  } catch {
    /* keep raw string if it isn't a well-formed URL */
  }

  useEffect(() => {
    panelRef.current?.focus();
  }, []);

  const handleGoBack = () => {
    if (onGoBack) return onGoBack();
    if (window.history.length > 1) {
      window.history.back();
    } else {
      window.location.href = "about:blank";
    }
  };

  const handleProceed = () => {
    if (onProceed) return onProceed(url);
    window.location.href = url;
  };

  return (
    <MotionConfig reducedMotion="user">
      <div className="warning-page">
        <div className="noise-overlay" />
        <div className="warning-bg-glow" />

        <div className="mini-brand">
          <FaShieldAlt />
          <span>LinkGuard AI</span>
        </div>

        <motion.main
          className="warning-panel"
          ref={panelRef}
          tabIndex={-1}
          role="alertdialog"
          aria-labelledby="warning-heading"
          aria-describedby="warning-desc"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        >
          <div className="warning-icon-ring">
            <FaShieldAlt className="warning-icon" />
          </div>

          <span className="warning-eyebrow">
            <span className="alert-dot" /> Site blocked
          </span>

          <h1 id="warning-heading">This Page Was Blocked</h1>

          <p id="warning-desc" className="warning-desc">
            LinkGuard AI flagged this page for signals commonly associated
            with phishing and scam sites. We recommend not entering any
            personal information here.
          </p>

          <div className="blocked-url-chip">
            <FaLockOpen />
            <span>{domain}</span>
          </div>

          <div className="reasons">
            <span className="reasons-label">Why we flagged this page</span>
            <div className="reasons-list">
              {reasons.map((r) => (
                <div className="reason-row" key={r.title}>
                  <span className="reason-icon">{r.icon}</span>
                  <div>
                    <h3>{r.title}</h3>
                    <p>{r.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="warning-actions">
            <button className="btn-safe" onClick={handleGoBack}>
              <FaArrowLeft /> Back to Safety
            </button>

            <button
              className="advanced-toggle"
              onClick={() => setAdvancedOpen(!advancedOpen)}
              aria-expanded={advancedOpen}
            >
              Advanced
              <FaChevronDown
                className={`chevron-icon ${advancedOpen ? "rotated" : ""}`}
              />
            </button>

            <div
              className={`advanced-wrap ${advancedOpen ? "open" : ""}`}
              aria-hidden={!advancedOpen}
            >
              <div className="advanced-panel">
                <p>
                  Proceeding may expose your passwords, personal details or
                  payment information to a malicious site. LinkGuard AI
                  can&apos;t protect you once you leave this page.
                </p>
                <button className="btn-proceed" onClick={handleProceed}>
                  Continue to {domain} anyway
                </button>
              </div>
            </div>
          </div>

          <button className="report-link" type="button">
            Think this is a mistake? Report it
          </button>
        </motion.main>

        <footer className="warning-footer">
          <p>Protected by LinkGuard AI · Real-time phishing detection</p>
        </footer>
      </div>
    </MotionConfig>
  );
}

export default Warning;