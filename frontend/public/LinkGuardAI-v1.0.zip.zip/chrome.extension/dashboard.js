async function loadDashboard(){

    const response = await fetch(

        "http://127.0.0.1:8000/scan/stats"

    );

    const data = await response.json();

    document.getElementById("total").innerHTML =
        data.total;

    document.getElementById("safe").innerHTML =
        data.safe;

    document.getElementById("phishing").innerHTML =
        data.phishing;

    document.getElementById("accuracy").innerHTML =
        data.accuracy + "%";

}

loadDashboard();